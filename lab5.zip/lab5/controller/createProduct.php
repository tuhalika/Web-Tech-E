<?php  
require_once '../model.php';


if (isset($_POST['createProduct'])) {
	$data['name'] = $_POST['name'];
	$data['buying price'] = $_POST['buying price'];
	$data['selling price'] = $_POST['selling price'];

  if (addStudent($data)) {
  	echo 'Successfully added!!';
  }
} else {
	echo 'You are not allowed to access this page.';
}

?>