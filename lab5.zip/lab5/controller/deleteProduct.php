<?php 

require_once '../model.php';

if (deleteStudent($_GET['name'])) {
    header('Location: ../showAllProducts.php');
}

 ?>