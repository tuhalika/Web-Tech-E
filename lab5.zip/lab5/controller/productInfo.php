<?php 

require_once 'model.php';

function fetchAllProducts(){
	return showAllProducts();

}
function fetchProduct($name){
	return showProduct($id);

}
