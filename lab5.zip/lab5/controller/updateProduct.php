<?php  
require_once '../model.php';


if (isset($_POST['updateProduct'])) {
	$data['name'] = $_POST['name'];
	$data['buying price'] = $_POST['buying price'];
	$data['selling price'] = $_POST['selling price'];

  if (updateProduct($_POST['name'], $data)) {
  	echo 'Successfully updated!!';
  	//redirect to showStudent
  	header('Location: ../showProduct.php?name=' . $_POST["name"]);
  }
} else {
	echo 'You are not allowed to access this page.';
}


?>