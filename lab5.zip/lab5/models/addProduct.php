<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        body {
            margin: 0;
        }
        .nav {
            display: inline;
        }
        .logo {
            display: inline;
        }
    </style>
</head>
<body>

 <form action="controller/createProduct.php" method="POST" enctype="multipart/form-data">
          <label for="name">Name: </label><br>
          <input type="text" name="name" id="name"><br>
         <label for="buying price">Buying Price: </label><br>
          <input type="text" name="buying price" id="buying price"><br>
          <label for="buying price">Selling Price: </label><br>
          <input type="text" name="selling price" id="selling price"><br>
          <hr>
         <input type="checkbox" id="Display" name="Display" value="Display">
        <label for="Display">Display</label><br>
        <hr>
  <input type="save" name = "createProduct" value="Create">
  <input type="reset"> 
</form> 

</body>
</html>

