<?php 

require_once 'controller/productInfo.php';
$product = fetchProduct($_GET['name']);

 ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

 <form action="controller/updateProduct.php" method="POST" enctype="multipart/form-data">
  <label for="name">Name:</label><br>
  <input value="<?php echo $product['Name'] ?>" type="text" id="name" name="name"><br>
  <label for="buying price">Buying Price:</label><br>
  <input value="<?php echo $product['buying price'] ?>" type="text" id="buying price" name="buying price"><br>
  <label for="selling price">Selling Price:</label><br>
  <input value="<?php echo $product['selling price'] ?>" type="text" id="selling price" name="selling price"><br>
  <input type="submit" name = "updateProduct" value="Update">
  <input type="reset"> 
</form> 

</body>
</html>

