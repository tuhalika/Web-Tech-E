<?php  
require_once 'controller/productInfo.php';

$products = fetchAllProducts();

?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

<table>
	<thead>
		<tr>
		<th>Name</th>
		<th>Buying Price</th>
		<th>Selling Price</th>
		<th>Action</th>
		</tr>
	</thead>
	<tbody>
		<?php foreach ($products as $i => $products): ?>
			<tr>
				<td><a href="showStudent.php?id=<?php echo $product['Name'] ?>"></a></td>
				<td><?php echo $product['Name'] ?></td>
				<td><?php echo $product['Buying Price'] ?></td>
				<td><?php echo $product['Selling Price'] ?></td>
				<td><a href="editProduct.php?id=<?php echo $product['Name'] ?>">Edit</a>&nbsp<a href="controller/deleteProduct.php?id=<?php echo $product['Name'] ?>">Delete</a></td>
			</tr>
		<?php endforeach; ?>
		

	</tbody>
	

</table>


</body>
</html>