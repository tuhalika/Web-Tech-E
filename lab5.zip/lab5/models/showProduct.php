<?php  
require_once 'controller/productInfo.php';

$product = fetchProduct($_GET['name']);

?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

<table>
	<tr>
		<th>Name</th>
		<th>Buying Price</th>
		<th>Selling Price</th>

	</tr>
	<tr>
		<td><a href="showProduct.php?name=<?php echo $product['Name'] ?>"></a></td>
		<td><?php echo $student['Name'] ?></td>
		<td><?php echo $student['Buying Price'] ?></td>
		<td><?php echo $student['Selling Price'] ?></td>
		
	</tr>

</table>


</body>
</html>