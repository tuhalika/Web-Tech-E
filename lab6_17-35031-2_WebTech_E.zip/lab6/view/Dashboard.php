	<?php
      $connect = mysqli_connect("localhost","root","","student");
	  if(!$connect){
		  echo("Error connection:".mysqli_connect_error());
	  }
	  if(isset($_POST['submit'])){
		  $sname  = $_POST['sname']; 
		  $spass  = $_POST['spass'];
		   $spass = md5($spass);
		 
		  
	$sql = "insert into register(Name,Password)
	values('$sname','$spass',)";
	$result = mysqli_query($connect,$sql);


	  }
	?>

 <!doctype html>
<html>
<head>
<meta charset="utf-8">
<title></title>
</head>

<body bgcolor="lightcyan">
<center>
<?php include 'me.php';?>
<input type="button" onclick="window.location='Dashboard.php'" class="Redirect" value="Dashboard"/>
<input type="button" onclick="window.location='View Profile.php'" class="Redirect" value="View Profile"/>
<input type="button" onclick="window.location='Edit Profile.php'" class="Redirect" value="Edit Profile"/>
<input type="button" onclick="window.location='change Password.php'" class="Redirect" value="Change Password "/>
<input type="button" onclick="window.location='student Courses.php'" class="Redirect" value="My Courses"/>
<input type="button" onclick="window.location='Public Home.php'" class="Redirect" value="Logout"/>

</center>
</body>
</html>