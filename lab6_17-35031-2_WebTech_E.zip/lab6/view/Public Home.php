<?php
?>
 <!doctype html>
<html>
<head>
<meta charset="utf-8">
<title></title>
</head>

<body bgcolor="lightcyan">
<center>
	<h2> Welocme to </h2>
	<p align="center"><img src="e learning.jpg" alt="me" style="width:220px;height:220px;"></p>
	<h3> Default Page </h3>

<input type="button" onclick="window.location='Student Login.php'" class="Redirect" value="Student Login"/>
<input type="button" onclick="window.location='Student Registration.php'" class="Redirect" value="Student Registration"/>


</center>
</body>
</html>