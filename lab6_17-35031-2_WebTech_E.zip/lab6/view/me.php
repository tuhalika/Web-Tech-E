
<!DOCTYPE html>
<html>
<head>
<style>
/* This style sets the width of all images to 100%: */
img {
  width: 100%;
}
</style>
  <title></title>
</head>
<body bgcolor="lightcyan">

<form action="welcome.php" method="post">

</div>
  <table align="center">
    <tr>
      <th colspan="2"><h2>Welcome Tuhalika</h2></th>
    </tr> 
  </table>
  <p align="center"><img src="me.jpg" alt="me" style="width:128px;height:128px;"></p> 
</form>

</body>
</html>