
<!DOCTYPE html>
<html>
<head>
<style>
/* This style sets the width of all images to 100%: */
img {
  width: 100%;
}
</style>
  <title></title>
</head>
<body bgcolor="lightcyan">

<form action="welcome.php" method="post">

</div>
  <p align="center"><img src="Books.jpg" alt="me" style="width:128px;height:128px;"></p>
  <table align="center">
    <tr>
      <th colspan="2"><h2> My Courses</h2></th>
    </tr>
    <tr>
      <td>Course Name</td>
      <td><label for="state"><span style="color:red;"> </span></label>
        <select name="state" id="state">
              <option selected disabled > Courses Name </option>
              <option value="Web Tech">Web Tech</option>
              <option value="Data Mining">Data Mining</option>
              <option value="Data Com">Data Com</option>
              <option value="Data Com">Math5</option>
              </select> <br>

      </td>
    </tr>

    <tr>
    <td align="right" colspan="2"><input type="button" onclick="window.location='Dashboard.php'" class="Redirect" value="Back"/></td>
    </tr>
    <tr>
    <td align="right" colspan="2"><input type="button" onclick="window.location='Public Home.php'" class="Redirect" value="Logout"/></td>
  </tr>


    </tr>
  </table>
  
</form>

</body>
</html>