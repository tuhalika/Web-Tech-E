
<!DOCTYPE html>
<html>
<head>
<style>
/* This style sets the width of all images to 100%: */
img {
  width: 100%;
}
</style>
	<title></title>
</head>
<body bgcolor="lightcyan">

<form action="welcome.php" method="post">

</div>
	<p align="center">
			
		</tr><img src="me.jpg" alt="me" style="width:128px;height:128px;"></p>
	<table align="center">
		<tr>
			<th colspan="2"><h2> Student Registration</h2></th>
		</tr>
		
	
		<tr>
			<td>Name</td>
			<td><input type="text" name="sname"></td>
		</tr>
		<tr>
			<td>Email</td>
			<td><input type="text" name="semail"></td>
		</tr>
		    <tr>
      <td>Password</td>
      <td><input type="password" name="spass"></td>
     </tr>
		<tr>
			<td>Occupation</td>
			<td><input type="occupation" name="soccupation"></td>
		</tr>
         <tr>
			<td>Upload Image</td>
			<td align="right" colspan="2"><input type="submit" name="choose file" value="choose file"> </td>
		</tr>
		<tr>
			<td align="right" colspan="2"><input type="submit" name="submit" value="send"></td>
         <tr>

	</table>
	
</form>

</body>
</html>