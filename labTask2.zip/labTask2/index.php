<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <style>
      p {
        color: red;
      }
    </style>
</head>

<body>

<div class="container">
<p>
<h3>EXPERIMENT NAME</h3>
Designing HTML form using PHP with validation of user inputs<br>
<h3>OBJECTIVE</h3>
This assessment item is designed to give you some practice on validating user inputs using PHP.<br>
<h3>ASSESSMENT TASK</h3>
Design the following HTML form and perform the following validations<br>
</p>
<?php
// define variables and set to empty values
$nameErr = $emailErr = $dateErr = $monthErr = $yearErr = $genderErr = $degreeErr = $blood_groupErr = "";
$name = $email = $date = $month = $year = $gender = $degree = $blood_group = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (empty($_POST["name"])) {
    $nameErr = "Name cannot be empty";
  } else {
    $name = test_input($_POST["name"]);
    // check if name only contains letters at the beginning,at least two wordsand can contain a-z, A-Z, period, dash only
    if (!preg_match("/^[A-Za-z][a-zA-Z-]+(?:\s[a-zA-Z]+)+$/",$name)) {
      $nameErr = " Must start with a letter, Contains at least two 
words and can contain a-z, A-Z, period, dash only";
    }
  }
}
  
  if (empty($_POST["email"])) {
    $emailErr = "Email cannot be empty";
  } else {
    $email = test_input($_POST["email"]);
    // check if e-mail address is well-formed
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $emailErr = "Invalid email format";
    }
  }

    if (empty($_POST["date"])) {
    $dateErr = "date cannot be empty";
  } else {
    $date = test_input($_POST["date"]);
   
    if (!preg_match("/^[1-31]+$/",$date)) {
      $dateErr = " Date must be between 1-31";
    }
  }

     if (empty($_POST["month"])) {
    $monthErr = "month cannot be empty";
  } else {
    $month = test_input($_POST["month"]);
   
    if (!preg_match("/^[1-12]+$/",$month)) {
      $monthErr = " Month must be between 1-12";
    }
  }

     if (empty($_POST["year"])) {
    $yearErr = "year cannot be empty";
  } else {
    $year = test_input($_POST["year"]);
   
    if (!preg_match("/^[1953-1998]+$/",$year)) {
      $yearErr = " Month must be between 1953-1998";
    }
  }


    if (empty($_POST["gender"])) {
    $genderErr = "Gender is required";
  } else {
    $gender = test_input($_POST["gender"]);
  }

  
   if (empty($_POST["degree"])) {
    $degreeErr = "Degree is required";
  } else {
    $degree = test_input($_POST["degree"]); 
}
    if (empty($_POST["blood_group"])) {
    $blood_groupErr = "Blood Group is required";
  } else {
    $blood_group = test_input($_POST["blood_group"]);
  }

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}

?>
<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post">

  <fieldset> 
  <div>

  <br>Name <br><input type="text" name="name" value="<?php echo $name;?>">
  <span class="error">* <?php echo $nameErr;?></span>
  <br><br>
  E-mail<br> <input type="text" name="email" value="<?php echo $email;?>">
  <span class="error">* <?php echo $emailErr;?></span>
  <br><br>
  <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post">

  <fieldset>
    <legend>Date of Birth</legend>
    <div>
  Date<br>
  <input type="number" min="1" max="31"name="date" value="<?php echo $date;?>">
  <span class="error"><br>* <?php echo $dateErr;?></span><br><br>
  Month<br>
  <input type="number" min="1" max="12"name="month" value="<?php echo $date;?>">
  <span class="error"><br>* <?php echo $monthErr;?></span>
  <br><br>
  Year<br>
  <input type="number" min="1953" max="1998"name="year" value="<?php echo $date;?>">
  <span class="error"><br>* <?php echo $yearErr;?></span>
  <br><br>
</div>
  </fieldset>
</form>
 Gender<br>
  <input type="radio" name="gender" <?php if (isset($gender) && $gender=="male") echo "checked";?> value="male">Male
   <input type="radio" name="gender" <?php if (isset($gender) && $gender=="female") echo "checked";?> value="female">Female
  <input type="radio" name="gender" <?php if (isset($gender) && $gender=="other") echo "checked";?> value="other">Other  
  <span class="error"> &nbsp * <?php echo $genderErr;?></span>
  <br><br>
Degree<br>
  <input type="checkbox" id="degree" name="degree" value="SSC">
  <label for="degree"> SSC</label>
  <input type="checkbox" id="degree" name="degree" value="HSC">
  <label for="degree"> HSC</label>
  <input type="checkbox" id="degree" name="degree" value="BSC">
  <label for="degree"> BSC</label>
  <input type="checkbox" id="degree" name="degree" value="MSC">
  <label for="degree"> MSC</label>
  <span class="error"> &nbsp * <?php echo $degreeErr;?></span>
  <br><br>
Blood Group<br>
   <select name="blood_group" id="blood_group">
   	<option selected disabled>Choose</option>
    <option value="A+">A+</option>
    <option value="B+">B+</option>
    <option value="AB+">AB+</option>
    <option value="O+">O+</option>
    <option value="A-">A-</option>
    <option value="B-">B-</option>
    <option value="AB-">AB-</option>
    <option value="O-">O-</option>
  </select>
    <span class="error"> &nbsp * <?php echo $blood_groupErr;?></span>
  <br><br>
<hr>
  <input type="submit" name="submit" value="Submit">  
   </div> 
  </fieldset>

</form>

<?php
echo "<h2>Your Input:</h2>";
echo $name;
echo "<br>";
echo $email;
echo "<br>";
echo $date;
echo "\n";
echo $month;
echo "\n";
echo $year;
echo "<br>";
echo $gender;
echo "<br>";
echo $degree;
echo "<br>";
echo $blood_group;
echo "<br>";
?>
</div>
</body>
</html>